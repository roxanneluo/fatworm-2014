run
make_data.py
to generate data
