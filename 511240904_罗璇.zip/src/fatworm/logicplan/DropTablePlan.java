package fatworm.logicplan;

import java.util.LinkedList;


public class DropTablePlan extends Plan {
	public LinkedList<String> tables = new LinkedList<String>();
	
	@Override
	public String getString(String tabs) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
