package fatworm.absyn;

public class Default extends Expr {
	public String toString() {
		return "DEFAULT";
	}
}
